package br.com.fishaquapets.petshop_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PetshopApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
